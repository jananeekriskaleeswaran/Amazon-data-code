Exact: heuristic = exact optimum (|diff| < 1e-9 %) on 9 of 20; max diff 4.97e-02 %; exact vs LB 0.120–0.763 %
Seeds: pooled 50 paired runs, decomp better in 42; median rel diff -0.0067 %; Wilcoxon p = 1.81e-10
station=DAU1 decomp_best=5.691e+07 decomp_median=5.692e+07 decomp_spread_pct=0.009312 ga_best=5.693e+07 ga_median=5.693e+07 ga_spread_pct=0.02246 median_diff_pct=-0.03 decomp_wins=10 gap_best_decomp=0.4037 gap_best_ga=0.4313 decomp_time_median=128 ga_time_median=752.2 wilcoxon_p=0.001953
station=DBO2 decomp_best=7.647e+07 decomp_median=7.647e+07 decomp_spread_pct=0.005858 ga_best=7.648e+07 ga_median=7.648e+07 ga_spread_pct=0.01076 median_diff_pct=-0.006292 decomp_wins=10 gap_best_decomp=0.1674 gap_best_ga=0.1744 decomp_time_median=99.96 ga_time_median=150.2 wilcoxon_p=0.001953
station=DCH1 decomp_best=5.303e+07 decomp_median=5.303e+07 decomp_spread_pct=0.02031 ga_best=5.304e+07 ga_median=5.304e+07 ga_spread_pct=0.01432 median_diff_pct=-0.007502 decomp_wins=8 gap_best_decomp=0.2492 gap_best_ga=0.2611 decomp_time_median=188.1 ga_time_median=270.7 wilcoxon_p=0.01367
station=DLA5 decomp_best=4.581e+07 decomp_median=4.582e+07 decomp_spread_pct=0.0102 ga_best=4.581e+07 ga_median=4.582e+07 ga_spread_pct=0.01427 median_diff_pct=-0.005123 decomp_wins=10 gap_best_decomp=0.3757 gap_best_ga=0.38 decomp_time_median=131.8 ga_time_median=253.7 wilcoxon_p=0.001953
station=DSE2 decomp_best=2.251e+07 decomp_median=2.251e+07 decomp_spread_pct=0.009473 ga_best=2.251e+07 ga_median=2.251e+07 ga_spread_pct=0.007796 median_diff_pct=0.001573 decomp_wins=4 gap_best_decomp=0.1162 gap_best_ga=0.1158 decomp_time_median=56.96 ga_time_median=89.63 wilcoxon_p=0.7695
Sensitivity (60): C gap 0.075–0.542 %; P at 1-day bound 51 of 60; C T 13.2–41.5 d; all feasible True
  exception: {'station': 'DSE2', 'param': 'fixed', 'factor': 1.5, 'C_gap': 0.11141502307141776, 'C_T': 20.897804303941143, 'P_at_1day': False, 'P_T': 20.897804303941143, 'P_vs_C': 0.2620048805704143, 'feasible': True}
  exception: {'station': 'DAU1', 'param': 'Ecap', 'factor': 0.5, 'C_gap': 0.4106023414319739, 'C_T': 33.34762548281184, 'P_at_1day': False, 'P_T': 19.595611069817902, 'P_vs_C': -0.36974014844561387, 'feasible': True}
  exception: {'station': 'DCH1', 'param': 'Ecap', 'factor': 0.5, 'C_gap': 0.26167628883003907, 'C_T': 19.957942385926916, 'P_at_1day': False, 'P_T': 1.2960070381190507, 'P_vs_C': -1.424090417383597, 'feasible': True}
  exception: {'station': 'DLA5', 'param': 'Ecap', 'factor': 0.5, 'C_gap': 0.3870647524889926, 'C_T': 33.90498406373001, 'P_at_1day': False, 'P_T': 13.520543353999333, 'P_vs_C': -0.37527348766531937, 'feasible': True}
  exception: {'station': 'DSE2', 'param': 'Ecap', 'factor': 0.5, 'C_gap': 0.13613225342710958, 'C_T': 17.907531864477193, 'P_at_1day': False, 'P_T': 17.461449490810313, 'P_vs_C': 0.11818529451749424, 'feasible': True}
  exception: {'station': 'DAU1', 'param': 'chi', 'factor': 0.5, 'C_gap': 0.41461484038621504, 'C_T': 33.34762548281184, 'P_at_1day': False, 'P_T': 19.595611069817902, 'P_vs_C': -0.37429414334506994, 'feasible': True}
  exception: {'station': 'DCH1', 'param': 'chi', 'factor': 0.5, 'C_gap': 0.2641687139000272, 'C_T': 19.957942385926916, 'P_at_1day': False, 'P_T': 1.2960070381190507, 'P_vs_C': -1.4498445400371471, 'feasible': True}
  exception: {'station': 'DLA5', 'param': 'chi', 'factor': 0.5, 'C_gap': 0.3910224844326712, 'C_T': 33.90498406373001, 'P_at_1day': False, 'P_T': 13.520543353999333, 'P_vs_C': -0.38030201374751393, 'feasible': True}
  exception: {'station': 'DSE2', 'param': 'chi', 'factor': 0.5, 'C_gap': 0.1374152413892711, 'C_T': 17.907531864477193, 'P_at_1day': False, 'P_T': 17.461449490810313, 'P_vs_C': 0.11990929602928521, 'feasible': True}
  exception: {'station': 'DAU1', 'param': 'tc', 'factor': 1.5, 'C_gap': 0.5416294633286138, 'C_T': 41.35639273407565, 'P_at_1day': True, 'P_T': 1.0, 'P_vs_C': -14.701314904481427, 'feasible': True}
  ('cp', 0.5): C gap max 0.496, C T 16.3-33.9, P_vs_C -35.0..-5.3
  ('cp', 1.5): C gap max 0.354, C T 16.3-33.9, P_vs_C -24.8..-3.7
  ('hold', 0.5): C gap max 0.283, C T 21.1-41.5, P_vs_C -28.8..-3.9
  ('hold', 1.5): C gap max 0.491, C T 13.2-27.2, P_vs_C -29.3..-4.8
  ('fixed', 0.5): C gap max 0.488, C T 17.5-27.2, P_vs_C -34.5..-22.1
  ('fixed', 1.5): C gap max 0.370, C T 16.3-35.3, P_vs_C -23.7..0.3
  ('Ecap', 0.5): C gap max 0.411, C T 16.3-33.9, P_vs_C -8.6..0.1
  ('Ecap', 1.5): C gap max 0.416, C T 16.3-33.9, P_vs_C -49.8..-24.9
  ('chi', 0.5): C gap max 0.415, C T 16.3-33.9, P_vs_C -8.7..0.1
  ('chi', 1.5): C gap max 0.412, C T 16.3-33.9, P_vs_C -49.2..-24.6
  ('tc', 0.5): C gap max 0.244, C T 14.0-23.2, P_vs_C -30.3..-5.4
  ('tc', 1.5): C gap max 0.542, C T 14.3-41.4, P_vs_C -27.9..-3.4
