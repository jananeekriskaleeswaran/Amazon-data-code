Superseded 2026-11-21: bounds used raw travel times in the radial term; recomputed with the shortest-path closure (out/runs/lb2, out/val/exact2, out/val/sens2).
