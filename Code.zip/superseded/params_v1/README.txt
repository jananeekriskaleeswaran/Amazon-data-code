Superseded 2026-11-23: realistic, EV and labour runs with the first parameter set (diesel 3.66, electricity 2024, eGRID2023); re-run with the author-supplied sources.
