Invalid: transport-cost scaling reached the bound but not the heuristic's vehicle cost (bug fixed 2026-11-21; re-run in out/val/sens).
