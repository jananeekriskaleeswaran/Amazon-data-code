Exact: heuristic = exact optimum (|diff| < 1e-9 %) on 9 of 20; max diff 4.97e-02 %; exact vs LB 0.120–0.763 %
Seeds: pooled 50 paired runs, decomp better in 42; median rel diff -0.0067 %; Wilcoxon p = 1.81e-10
station=DAU1 decomp_best=5.691e+07 decomp_median=5.692e+07 decomp_spread_pct=0.009312 ga_best=5.693e+07 ga_median=5.693e+07 ga_spread_pct=0.02246 median_diff_pct=-0.03 decomp_wins=10 gap_best_decomp=0.4257 gap_best_ga=0.4533 decomp_time_median=128 ga_time_median=752.2 wilcoxon_p=0.001953
station=DBO2 decomp_best=7.647e+07 decomp_median=7.647e+07 decomp_spread_pct=0.005858 ga_best=7.648e+07 ga_median=7.648e+07 ga_spread_pct=0.01076 median_diff_pct=-0.006292 decomp_wins=10 gap_best_decomp=0.1718 gap_best_ga=0.1788 decomp_time_median=99.96 ga_time_median=150.2 wilcoxon_p=0.001953
station=DCH1 decomp_best=5.303e+07 decomp_median=5.303e+07 decomp_spread_pct=0.02031 ga_best=5.304e+07 ga_median=5.304e+07 ga_spread_pct=0.01432 median_diff_pct=-0.007502 decomp_wins=8 gap_best_decomp=0.2528 gap_best_ga=0.2648 decomp_time_median=188.1 ga_time_median=270.7 wilcoxon_p=0.01367
station=DLA5 decomp_best=4.581e+07 decomp_median=4.582e+07 decomp_spread_pct=0.0102 ga_best=4.581e+07 ga_median=4.582e+07 ga_spread_pct=0.01427 median_diff_pct=-0.005123 decomp_wins=10 gap_best_decomp=0.379 gap_best_ga=0.3833 decomp_time_median=131.8 ga_time_median=253.7 wilcoxon_p=0.001953
station=DSE2 decomp_best=2.251e+07 decomp_median=2.251e+07 decomp_spread_pct=0.009473 ga_best=2.251e+07 ga_median=2.251e+07 ga_spread_pct=0.007796 median_diff_pct=0.001573 decomp_wins=4 gap_best_decomp=0.1169 gap_best_ga=0.1166 decomp_time_median=56.96 ga_time_median=89.63 wilcoxon_p=0.7695
Sensitivity (80): C gap 0.075–0.574 %; P at 1-day bound 70 of 80; C T 12.9–41.5 d; all feasible True
  exception: {'station': 'DAU1', 'param': 'cp', 'factor': 0.5, 'C_gap': 0.5226644111173893, 'C_T': 33.34762548281184, 'P_at_1day': True, 'P_T': 1.0, 'P_vs_C': -21.424929140786958, 'feasible': True}
  exception: {'station': 'DAU1', 'param': 'hold', 'factor': 1.5, 'C_gap': 0.5124578740476766, 'C_T': 26.922965739158375, 'P_at_1day': True, 'P_T': 1.0, 'P_vs_C': -18.145778379961367, 'feasible': True}
  exception: {'station': 'DAU1', 'param': 'fixed', 'factor': 0.5, 'C_gap': 0.5103607185715948, 'C_T': 26.922965739158375, 'P_at_1day': True, 'P_T': 1.0, 'P_vs_C': -26.530999471730574, 'feasible': True}
  exception: {'station': 'DSE2', 'param': 'fixed', 'factor': 1.5, 'C_gap': 0.11213412147915379, 'C_T': 20.897804303941143, 'P_at_1day': False, 'P_T': 20.897804303941143, 'P_vs_C': 0.2620048805704143, 'feasible': True}
  exception: {'station': 'DAU1', 'param': 'Ecap', 'factor': 0.5, 'C_gap': 0.432471512440326, 'C_T': 33.34762548281184, 'P_at_1day': False, 'P_T': 19.595611069817902, 'P_vs_C': -0.36974014844561387, 'feasible': True}
  exception: {'station': 'DCH1', 'param': 'Ecap', 'factor': 0.5, 'C_gap': 0.2652875106844723, 'C_T': 19.957942385926916, 'P_at_1day': False, 'P_T': 1.2960070381190507, 'P_vs_C': -1.424090417383597, 'feasible': True}
  exception: {'station': 'DLA5', 'param': 'Ecap', 'factor': 0.5, 'C_gap': 0.3903229744622957, 'C_T': 33.90498406373001, 'P_at_1day': False, 'P_T': 13.520543353999333, 'P_vs_C': -0.37527348766531937, 'feasible': True}
  exception: {'station': 'DSE2', 'param': 'Ecap', 'factor': 0.5, 'C_gap': 0.13684993971143253, 'C_T': 17.907531864477193, 'P_at_1day': False, 'P_T': 17.461449490810313, 'P_vs_C': 0.11818529451749424, 'feasible': True}
  exception: {'station': 'DAU1', 'param': 'chi', 'factor': 0.5, 'C_gap': 0.4366956584051141, 'C_T': 33.34762548281184, 'P_at_1day': False, 'P_T': 19.595611069817902, 'P_vs_C': -0.37429414334506994, 'feasible': True}
  exception: {'station': 'DCH1', 'param': 'chi', 'factor': 0.5, 'C_gap': 0.26781550673126425, 'C_T': 19.957942385926916, 'P_at_1day': False, 'P_T': 1.2960070381190507, 'P_vs_C': -1.4498445400371471, 'feasible': True}
  exception: {'station': 'DLA5', 'param': 'chi', 'factor': 0.5, 'C_gap': 0.39431229871580664, 'C_T': 33.90498406373001, 'P_at_1day': False, 'P_T': 13.520543353999333, 'P_vs_C': -0.38030201374751393, 'feasible': True}
  exception: {'station': 'DSE2', 'param': 'chi', 'factor': 0.5, 'C_gap': 0.1381399706482439, 'C_T': 17.907531864477193, 'P_at_1day': False, 'P_T': 17.461449490810313, 'P_vs_C': 0.11990929602928521, 'feasible': True}
  exception: {'station': 'DAU1', 'param': 'tc', 'factor': 1.5, 'C_gap': 0.5739787415534849, 'C_T': 41.35639273407565, 'P_at_1day': True, 'P_T': 1.0, 'P_vs_C': -14.701314904481427, 'feasible': True}
  exception: {'station': 'DSE2', 'param': 'demand', 'factor': 0.8, 'C_gap': 0.16169767724268166, 'C_T': 26.109333864843467, 'P_at_1day': False, 'P_T': 12.934894158903006, 'P_vs_C': -0.07287368105268667, 'feasible': True}
  ('cp', 0.5): C gap max 0.523, C T 16.3-33.9, P_vs_C -35.0..-5.3
  ('cp', 1.5): C gap max 0.373, C T 16.3-33.9, P_vs_C -24.8..-3.7
  ('hold', 0.5): C gap max 0.305, C T 21.1-41.5, P_vs_C -28.8..-3.9
  ('hold', 1.5): C gap max 0.512, C T 13.2-27.2, P_vs_C -29.3..-4.8
  ('fixed', 0.5): C gap max 0.510, C T 17.5-27.2, P_vs_C -34.5..-22.1
  ('fixed', 1.5): C gap max 0.392, C T 16.3-35.3, P_vs_C -23.7..0.3
  ('Ecap', 0.5): C gap max 0.432, C T 16.3-33.9, P_vs_C -8.6..0.1
  ('Ecap', 1.5): C gap max 0.438, C T 16.3-33.9, P_vs_C -49.8..-24.9
  ('chi', 0.5): C gap max 0.437, C T 16.3-33.9, P_vs_C -8.7..0.1
  ('chi', 1.5): C gap max 0.433, C T 16.3-33.9, P_vs_C -49.2..-24.6
  ('tc', 0.5): C gap max 0.245, C T 14.0-23.2, P_vs_C -30.3..-5.4
  ('tc', 1.5): C gap max 0.574, C T 14.3-41.4, P_vs_C -27.9..-3.4
  ('ttimp', 0.8): C gap max 0.444, C T 16.3-34.0, P_vs_C -29.2..-4.4
  ('ttimp', 1.2): C gap max 0.406, C T 16.3-33.9, P_vs_C -29.1..-4.4
  ('demand', 0.8): C gap max 0.488, C T 15.9-35.3, P_vs_C -25.8..-0.1
  ('demand', 1.2): C gap max 0.373, C T 12.9-34.6, P_vs_C -31.1..-10.6
